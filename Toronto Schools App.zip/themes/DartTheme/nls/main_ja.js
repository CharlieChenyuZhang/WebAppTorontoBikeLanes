// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/DartTheme/nls/strings":{_themeLabel:"\u30c0\u30fc\u30c8 \u30c6\u30fc\u30de",_layout_default:"\u30c7\u30d5\u30a9\u30eb\u30c8\u306e\u30ec\u30a4\u30a2\u30a6\u30c8",_localized:{}}});