// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/PlateauTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Ba\u015fl\u0131k Denetleyici",signin:"Oturum A\u00e7",signout:"Oturumu Kapat",about:"Hakk\u0131nda",signInTo:"\u015eurada oturum a\u00e7:",cantSignOutTip:"Bu i\u015flev \u00f6n izleme modunda yok.",_localized:{}}});