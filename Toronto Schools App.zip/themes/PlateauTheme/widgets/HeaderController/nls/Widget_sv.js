// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/PlateauTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Rubrikhanterare",signin:"H\u00e4mtar %1",signout:"Logga ut",about:"Om",signInTo:"Logga in p\u00e5",cantSignOutTip:"Denna funktion \u00e4r inte tillg\u00e4nglig i f\u00f6rhandsgranskningsl\u00e4ge.",_localized:{}}});