// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/PlateauTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Controlador de encabezado",signin:"Inicia sesi\u00f3n",signout:"Cerrar sesi\u00f3n",about:"Acerca de",signInTo:"Iniciar sesi\u00f3n en",cantSignOutTip:"Esta funci\u00f3n no est\u00e1 disponible en el modo de vista previa.",_localized:{}}});