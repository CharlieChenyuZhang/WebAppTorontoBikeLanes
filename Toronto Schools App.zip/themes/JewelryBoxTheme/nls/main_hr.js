// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"Tema kutije s nakitom",_layout_default:"Zadani izgled",_layout_layout1:"Izgled 1",emptyDocablePanelTip:"Kliknite na gumb + u kartici widgeta da biste dodali widget. ",_localized:{}}});