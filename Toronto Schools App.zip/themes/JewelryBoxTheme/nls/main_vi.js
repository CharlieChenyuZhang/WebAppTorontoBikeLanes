// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"Ch\u1ee7 \u0111\u1ec1 H\u1ed9p Trang s\u1ee9c",_layout_default:"B\u1ed1 c\u1ee5c m\u1eb7c \u0111\u1ecbnh",_layout_layout1:"B\u1ed1 c\u1ee5c 1",emptyDocablePanelTip:"B\u1ea5m v\u00e0o n\u00fat + trong tab Ti\u1ec7n \u00edch \u0111\u1ec3 th\u00eam ti\u1ec7n \u00edch. ",_localized:{}}});