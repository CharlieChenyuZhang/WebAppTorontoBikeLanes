// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"Tem\u0103 cutie bijuterii",_layout_default:"Configura\u0163ie implicit\u0103",_layout_layout1:"Aspectul 1",emptyDocablePanelTip:"Face\u0163i clic pe butonul + din fila Widget pentru a ad\u0103uga un widget. ",_localized:{}}});