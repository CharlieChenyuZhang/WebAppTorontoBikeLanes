// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"Tema Kutija za nakit",_layout_default:"Podrazumevani raspored",_layout_layout1:"Raspored 1",emptyDocablePanelTip:"Kliknite na dugme \u201e+\u201c u kartici vid\u017eeta da biste dodali vid\u017eet. ",_localized:{}}});