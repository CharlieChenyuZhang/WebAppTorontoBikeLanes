// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/nls/strings":{_themeLabel:"\u73e0\u5b9d\u76d2\u4e3b\u9898",_layout_default:"\u9ed8\u8ba4\u5e03\u5c40",_layout_layout1:"\u5e03\u5c40 1",emptyDocablePanelTip:"\u5728\u5fae\u4ef6\u9009\u9879\u5361\u4e2d\u5355\u51fb + \u6309\u94ae\u4ee5\u6dfb\u52a0\u5fae\u4ef6\u3002 ",_localized:{}}});