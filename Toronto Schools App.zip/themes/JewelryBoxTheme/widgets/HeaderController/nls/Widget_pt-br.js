// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Controlador do Cabe\u00e7alho",signin:"Acessar",signout:"Sair",about:"Sobre o",signInTo:"Entrar no",cantSignOutTip:"Esta fun\u00e7\u00e3o \u00e9 N/A no modo de visualiza\u00e7\u00e3o.",more:"mais",_localized:{}}});