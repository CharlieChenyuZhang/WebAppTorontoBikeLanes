// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/JewelryBoxTheme/widgets/HeaderController/setting/nls/strings":{group:"Nome",openAll:"Abrir Todos no Painel",dropDown:"Mostrar no Menu Suspenso",noGroup:"N\u00e3o h\u00e1 grupo de widget configurado.",groupSetLabel:"Configurar propriedades de grupos do widget",_localized:{}}});